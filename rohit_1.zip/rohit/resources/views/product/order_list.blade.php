@extends('layouts.app')
@section('content')

<br />

<table class="table table-bordered table-striped">
 <tr> 
  <th>Order id</th>
  <th>Product name</th>
  <th>total</th>
  <th>email</th>
  <th>quantity</th>
  <th>time</th>
 </tr>
 @foreach($data as $row)  
  <tr>
  
   <td>{{ $row->order_id }}</td>
   <td>{{ $row->name }}</td>
   <td>{{ $row->total }}</td>
   <td>{{ $row->email }}</td>
   <td>{{ $row->quantity }}</td>
   <td>{{ $row->updated_at }}</td>
   
  </tr>
 @endforeach
</table>
{!! $data->links() !!}
@endsection
