<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string("name");
            $table->string("quantity");
            $table->string("total");
            $table->string("email");
            $table->string("order_id");
            $table->timestamps();
            $table->foreign('email')->references('email')->on('users')->onDelete('cascade');
            $table->foreign('name')->references('Name')->on('cruds')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
