<?php $__env->startSection('content'); ?>

<br />

<table class="table table-bordered table-striped">
 <tr> 
  <th>Order id</th>
  <th>Product name</th>
  <th>total</th>
  <th>email</th>
  <th>quantity</th>
  <th>time</th>
 </tr>
 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
  <tr>
  
   <td><?php echo e($row->order_id); ?></td>
   <td><?php echo e($row->name); ?></td>
   <td><?php echo e($row->total); ?></td>
   <td><?php echo e($row->email); ?></td>
   <td><?php echo e($row->quantity); ?></td>
   <td><?php echo e($row->updated_at); ?></td>
   
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $data->links(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp2\www\rohit\resources\views/product/order_list.blade.php ENDPATH**/ ?>