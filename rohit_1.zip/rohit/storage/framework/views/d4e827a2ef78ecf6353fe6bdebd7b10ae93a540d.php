<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center">
 <div align="right">
  <a href="<?php echo e(route('crud.index')); ?>" class="btn btn-default">Back</a>
 </div>
 <br />
 <img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($data->image); ?>" class="img-thumbnail" />
 <h3>First Name - <?php echo e($data->first_name); ?> </h3>
 <h3>Last Name - <?php echo e($data->last_name); ?></h3>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp2\www\rohit\resources\views/product/view.blade.php ENDPATH**/ ?>