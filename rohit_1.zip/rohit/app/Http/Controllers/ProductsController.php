<?php
 
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Crud;
use App\Order;
use DB;
use Session;

use Illuminate\Support\Facades\Auth;
 
class ProductsController extends Controller
{
	

  public function index()
    {
       $products = Crud::where('Stock','>' , 0)->paginate(12);

        return view('products', compact('products'));
    }
 
    public function cart()
    {
        return view('cart');
    }

     public function Order(Request $request)
    {
    	if (Auth::user()) {
            $email= Auth::user()->email;
             $orders = Order::all();
       if($orders->isEmpty()){

        $ord=1;
        }
 
 else{
       $last_row=DB::table('orders')->orderBy('id', 'DESC')->first();
      if($last_row->id)
       $ord=$last_row->id + 1;
    }
     $order_id = 'ORD00'.$ord;
     
     $data=$request->all();
     //echo $data['name'][0];
      //$form_data = [];

for ($i = 0; $i < count($data['quantity']); $i++) {
    $form_data = array(
        'name' => $data['name'][$i],
        'quantity' => $data['quantity'][$i],
        'total' => $data['total'][$i],
        'email' => $email,
        'order_id' => $order_id
    );
    Order::create($form_data);

   // dd($form_data);
        
         $s1=DB::table('cruds')->where('Name', $data['name'][$i])->first()->Stock;
    
            $s2=$s1-($data['quantity'][$i]);
              DB::table('cruds')
                ->where("Name", '=', $data['name'][$i])
                ->update(['Stock'=> $s2]); 
     }
                Session::flush();
       return redirect('/')->with('success', 'Order success.');;
    }
    return redirect('/login');
    }

    public function addToCart($id)
    {
 		$product = Crud::find($id);
 
        if(!$product) {
 
            abort(404);
 
        }
 
        $cart = session()->get('cart');
 
        // if cart is empty then this the first product
        if(!$cart) {
 
            $cart = [
                    $id => [
                        "name" => $product->Name,
                        "quantity" => 1,
                        "price" => $product->Price,
                        "image" => $product->image
                    ]
            ];
 
            session()->put('cart', $cart);
 
            return redirect()->back()->with('success', 'Product added to cart successfully!');
        }
 
        // if cart not empty then check if this product exist then increment quantity
        if(isset($cart[$id])) {
 
            $cart[$id]['quantity']++;
 
            session()->put('cart', $cart);
 
            return redirect()->back()->with('success', 'Product added to cart successfully!');
 
        }
 
        // if item not exist in cart then add to cart with quantity = 1
        $cart[$id] = [
            "name" => $product->Name,
            "quantity" => 1,
            "price" => $product->Price,
            "image" => $product->image
        ];
 
        session()->put('cart', $cart);
 
        return redirect()->back()->with('success', 'Product added to cart successfully!');
    }
    public function update(Request $request)
    {
        if($request->id and $request->quantity)
        {
            $cart = session()->get('cart');
 
            $cart[$request->id]["quantity"] = $request->quantity;
 
            session()->put('cart', $cart);
 
            session()->flash('success', 'Cart updated successfully');
        }
    }
 
    public function remove(Request $request)
    {
        if($request->id) {
 
            $cart = session()->get('cart');
 
            if(isset($cart[$request->id])) {
 
                unset($cart[$request->id]);
 
                session()->put('cart', $cart);
            }
 
            session()->flash('success', 'Product removed successfully');
        }
    }

    public function order_list()
    {
        $data = Order::latest()->paginate(5);
        return view('product.order_list', compact('data'));
                // ->with('i', (request()->input('page', 1) - 1) * 5);
    }


}