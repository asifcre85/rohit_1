<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Crud extends Model
{
    protected $fillable = [
        'Category', 'Name','Code', 'Stock','Price', 'image'
       ];
}
